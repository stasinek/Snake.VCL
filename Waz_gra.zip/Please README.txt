Jak gra�::

Wybierz z menu Graj->Mapka->i nazwa pliku mapy, nast�pnie z menu Graj->Start lub naci�nij "G"

NEW!!!
Klawisze::

"G" - zacznij gr�
"P" - pauza
"Esc" - stop
"O" - opcje
"E" - EXIT
"F1"..."F12" zmie� map�

Konfiguracja ::

NEW!!!
Pliki *.lev mo�na dowolnie tworzy� i nadawa� dowolne nazwy, maxymalnie mo�e by� ich 12 zmieniane F1-F12 lub w menu

W pliku *.lev znajduje si� textowy obraz i u�o�enie �cian "1" oznacza �e tu jest przeszkoda
a cokolwiek innego np.0 oznacza pust� przestrze�
w pliku konfiguracji przed map� nale�y umie�cic linijk� "end!" bez niej program si� zeb�dzi
Elementy grafiki s� w plikach map.bmp(kafle sienne) ,nic.bmp(kafle tlane)
kropa.bmp(pier�cienie w�a) ,zbier.bmp(kafle zbierajek;wyd�_�ajek)
kropao.bmp(g�owa w�a), bonus.bmp, clock.bmp
Pozwala to na zmiane INTERFACE'u bez ponownej kompilacji!


Info:::

Pliki programu:
*.bmp
*.wav
*.txt
waz.exe

//---------------------------------------------------------------------
